<?php
session_start();
include 'db_connect.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $data = $_POST['data'];
    $user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null;

    $query = "INSERT INTO data_table (data, user_id) VALUES ('$data', '$user_id')";
    if (mysqli_query($conn, $query)) {
        echo "Data inserted successfully.";
    } else {
        echo "Error: " . $query . "<br>" . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Insert Data</title>
</head>
<body>
    <form method="POST" action="">
        <label for="data">Data:</label>
        <input type="text" name="data" id="data" required><br>
        <button type="submit">Insert Data</button>
    </form>
</body>
</html>
