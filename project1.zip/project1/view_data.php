<?php
session_start();
include 'db_connect.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

$query = "SELECT * FROM data_table WHERE user_id = '$user_id'";
$result = mysqli_query($conn, $query);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Your Data</title>
</head>
<body>
    <h1>Your Inserted Data</h1>
    <table border="1">
        <tr>
            <th>ID</th>
            <th>Data</th>
            <th>User ID</th>
        </tr>
        <?php
        while ($row = mysqli_fetch_assoc($result)) {
            echo "<tr>";
            echo "<td>" . $row['id'] . "</td>";
            echo "<td>" . $row['data'] . "</td>";
            echo "<td>" . $row['user_id'] . "</td>";
            echo "</tr>";
        }
        ?>
    </table>
    <p><a href="logout.php">Logout</a></p>
    <p><a href="welcome.php">Back to Welcome Page</a></p>
</body>
</html>
